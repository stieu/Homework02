# Homework02
Homework 2: Bessel functions as integrals, plots  
Note: you need both `Homework_02.ipynb` and `gaussxw.py` to do the homework
